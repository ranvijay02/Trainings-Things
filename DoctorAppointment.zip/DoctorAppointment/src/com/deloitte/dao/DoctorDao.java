package com.deloitte.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.deloitte.bean.Appointment;
import com.deloitte.bean.Doctor;

@Transactional
@Repository
public class DoctorDao implements IDoctorDao {

	@PersistenceContext
	EntityManager entityManager;
	Logger logger = Logger.getLogger(DoctorDao.class);
	

	@Override
	public List<String> getCategory() {
		TypedQuery<String> query = null;// HQL
		String hql = "SELECT c.category from Category c";
		if (entityManager == null) {
			System.out.println("Null is returned");
			return null;
		} else {

			query = entityManager.createQuery(hql, String.class);
			logger.info("Fetching categories ");
			return query.getResultList();
		}
	}

	@Override
	public int addDoctor(Doctor doctor) {
		System.out.println("DAO : " + doctor);
		entityManager.persist(doctor);
		logger.info("Saved Athlete : " + doctor.getName());
		return 1;
	}

	@Override
	public List<Doctor> getDoctorList() {
		String sql = "SELECT list from Doctor list";
		TypedQuery<Doctor> query = entityManager.createQuery(sql, Doctor.class);
		   logger.info("Fetching Athletes  ");
		return query.getResultList();
	}


	@Override
	public List<Doctor> getDoctorList(String category) {
		String sql = "SELECT list from Doctor list where category= :category";
		TypedQuery<Doctor> query = entityManager.createQuery(sql, Doctor.class);
		query.setParameter("category", category);
		   logger.info("Fetching Athletes  ");
		return query.getResultList();
	}


	@Override
	public int addAppointment(Appointment appointment) {
		System.out.println("DAO : " + appointment);
		entityManager.persist(appointment);
		logger.info("Saved Athlete : " + appointment.getName());
		return 1;
	}

	@Override
	public int addDoctorId(String doctor_id, String patient_id) {
//		String sql = "update Appointment set doctor_id = :doctor_id" + " where id = :patiend_id";
//		TypedQuery<Doctor> query = entityManager.createQuery(sql, Doctor.class);
//		query.setParameter("doctor_id", doctor_id);
//		query.setParameter("patient_id", patient_id);
//		   logger.info("Fetching Athletes  ");
//		return query.executeUpdate();
		return 0;
	}
}
