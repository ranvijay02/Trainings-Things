package com.deloitte;
class Test{
	  Test() throws ArithmeticException  {
	  }
	  public static void main (String[] args) throws Exception {
	    Test t = new Test();
	  }
	}

