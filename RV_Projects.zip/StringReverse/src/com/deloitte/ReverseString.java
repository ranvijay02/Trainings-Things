package com.deloitte;
import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		
		System.out.println("Enter a string");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		Reverse r = new Reverse();
		String reversestring = r.reverse(str);
		System.out.println(reversestring);
		
		CountVowel c = new CountVowel();
		int vowelcount = c.countVowel(reversestring);
		System.out.println(vowelcount + " vowels");
	
	}

}