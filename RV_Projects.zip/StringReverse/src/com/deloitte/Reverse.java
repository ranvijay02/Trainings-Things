package com.deloitte;

public class Reverse {
	
	String reverse(String str) {
		String reversestring = "";
		
		for(int i = str.length() - 1; i>=0; i--) {
			reversestring = reversestring + str.charAt(i);
		}
		
		return reversestring;
	}

}
