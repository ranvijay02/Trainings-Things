package com.deloitte;

public class Child extends Test {
Child() {
	
}
}
