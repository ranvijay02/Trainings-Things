package com.deloitte.util;

public class BankingMessage {
	
	public static final String INSUFFICIENT_BALANCE = "Insufficient Balance";
	

}
